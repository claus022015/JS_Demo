
# Enable `sphinxcontrib-jsdemo` extension.
extensions = ['sphinxcontrib.jsdemo']

# Standard configuration.
project = u'A Project with HTML/Javascript Demos'
master_doc = 'index'
exclude_patterns = ['_build']

