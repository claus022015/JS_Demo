

$(function () {
    $('.demo-header').click(function () {
        $(this).toggleClass('demo-hide');
    });
});


